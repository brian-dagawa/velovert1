<h3>MEMBRE</h3>
<form method="post">
<table>
		<tr><td>Login </td><td><input type="text" name="loginmembre"></td></tr>
		<tr><td>Password</td><td><input type="password" name="passwordmembre" ></td></tr>
		<tr><td><input type="submit" name="membre" value="Entrer"></td>
</table>

<h3>ADMINISTRATEUR</h3>
<form method="post">
<table>
		<tr><td>ADMIN</td><td><input type="text" name="loginadmin"></td></tr>
		<tr><td>Password</td><td><input type="password" name="passwordadmin" ></td></tr>
		<tr><td><input type="submit" name="admin" value="Entrer"></td>
</table>
</form>
<?php


/***************Debut sectiob membre*******/
if(isset($_POST["membre"]))
{
	include("connexion.php");
	//1 recuperation des donnes par post)
	$loginmembre=$_POST["loginmembre"];
	$passwordmembre=$_POST["passwordmembre"];
	//2)requete de selection
	$reqmembre=mysqli_query($conn,"select * from amis where noami='$loginmembre' and password='$passwordmembre'") or die("erreur de requete");
	//3)annalyse
	$nbre=mysqli_num_rows($reqmembre);
	if($nbre==1)
	{
		$_SESSION["loginmembre"]=$loginmembre;
		$_SESSION["passwordmembre"]=$passwordmembre;
echo"<script>window.location.href='membre/indexmembre.php';</script>";
	}
	else
	{
	echo"login ou password incorect";
	}
}

?>

<?php


/***************Debut sectiob membre*******/
if(isset($_POST["admin"]))
{
	include("connexion.php");
	//1 recuperation des donnes par post)
	$loginadmin=$_POST["loginadmin"];
	$passwordadmin=$_POST["passwordadmin"];
	//2)requete de selection
	$reqadmin=mysqli_query($conn,"select * from admin where login='$loginadmin' and password='$passwordadmin'") or die("erreur du requete selection");
	//3)annalyse
	$nbre=mysqli_num_rows($reqadmin);
	if($nbre==1)
	{
		$_SESSION["loginadmin"]=$loginadmin;
		$_SESSION["passwordadmin"]=$passwordadmin;
echo"<script>window.location.href='admin/indexadmin.php';</script>";
	}
	else
	{
	echo"login ou password incorect";
	}
}

?>