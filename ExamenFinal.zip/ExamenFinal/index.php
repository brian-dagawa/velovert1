<?php
// demarrage de la session 
if(!isset($_SESSION))
{
session_start();
//echo session_id();
}
?>

<style>
	li{
		display:inline;
		margin-right:100px;
	}
	
</style>
<center>

		
		<!-- menu -->
		<div style="height:5%;width:80%;background-color:white;">
			<ol>
				<li><a href="index.php?lien=accueil"><b>Accueil</b></a> </li>
				<li><a href="index.php?lien=login"><b>Login</b> </a> </li>
				<li><a href="index.php?lien=inscrire"><b>Inscrire</b> </a> </li>
				
			</ol>
		</div>

		<!-- details -->
		<div style="height:60%;width:80%;">
		


		<?php
		include("connexion.php");
		 //Recuperation de la valeur du lien(lien can be given any name)
		 if(isset($_GET["lien"]))
		 {
			 $lien =$_GET["lien"];
			//selon le lien clique, inclure le contenu de la case
			switch($lien)
			{
				case"accueil":
				   include("accueil.php");
				break;
				case"login":
					include("login.php");
				break;
				case"inscrire":
					include("inscrire.php");
				break;
				
			}
		  }
			 ELSE
		 {
			 include("accueil.php");
		 }
	
		?>

</div>
				

