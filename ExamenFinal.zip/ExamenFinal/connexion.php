<?php
$conn=mysqli_connect('localhost','root','','velovert') 
or die ("Erreur de connexion avec Mysql!");
?>