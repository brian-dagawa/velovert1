<body style="background-color:orange">
<style>
	li{
		display:inline;
		margin-right:100px;
	}
	
</style>
<center>
	
		<!-- menu -->
		<div style="background-color:white
		;">
			<ol>
				<li><a href="indexmembre.php?lien=accueuille">Accueil</a> </li>
				<li><a href="indexmembre.php?lien=liste">Afficher vello  </a> </li>
				<li><a href="indexmembre.php?lien=profile">Profile  </a> </li>
				<li><a href="indexmembre.php?lien=recherche">Recherche velo </a> </li>
				<li><a href="indexmembre.php?lien=deconnexion">Deconection </a> </li>
			</ol>
		</div>

		<!-- details -->
		<?php
		 //Recuperation de la valeur du lien(lien can be given any name)
		 if(isset($_GET["lien"]))
		 {
			 $lien =$_GET["lien"];
			//selon le lien clique, inclure le contenu de la case
			switch($lien)
			{
				case"accueuille":
				   include("accueuille.php");
				break;
				case"liste":
					include("liste.php");
				break;
				case"profile":
					include("profile.php");
				break;
				case"recherche":
					include("recherche.php");
				break;
				case"deconnexion":
					include("deconnexion.php");
				break;
			}
		 }
		?>
		
</center>
</body>