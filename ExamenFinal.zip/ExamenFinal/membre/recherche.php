
<form method="post">
	<input type="text" name="search" value="" >
	<input type="submit" name="recherche" value="Rechercher...">
</form>
<script type="text/javascript">
function imprimer(page) {
	window.open(page,"Impression","menubar=no, status=no, scrollbars=no, menubar=no, width=900, height=900");
}
</script>
<?php

if(isset($_POST["recherche"]))
{
	//1)Recuperation des donnees recherchees
	$search=$_POST["search"];
	$stotal=0;
	$tps=0;
	$tvq=0;
	$total=0;
	//2)connexion a la BD
	include("../connexion.php");
	//3) Requete de selection de livre
	$affichelivre=mysqli_query($conn,"select * from velo 
	where novelo='$search' or marque='$search' ");
	$nbretrouve=mysqli_num_rows($affichelivre);
	if($nbretrouve >0)
	{
		//3) Affichage des livres
		echo"<table><tr><th>novelo </th> <th>marque </th>
		<th>Prix </th><th> Photo</th></tr>";
		while($resultatlivre=mysqli_fetch_row($affichelivre))
		{
			$novelo=$resultatlivre[0];
			$marque=$resultatlivre[1];
			$prix=$resultatlivre[2];
			$photo=$resultatlivre[3];
			//Calcul du sous-total
			$stotal +=$prix;
			echo"<tr><td>$novelo </td> <td> $marque</td>
			<td> $prix$</td>
			<td><img src='photos/$photo' style='height:150px;width:150px;'> 
			</td></tr>";
		}
		//Calcul des taxes et du total
		$tps=$stotal*0.05;
		$tvq=$stotal*0.975;
		$total=$stotal+$tps+$tvq;
		echo"<tr><td colspan='4' align='right'>Sous-Total: $stotal$</td> </tr>
		<tr><td colspan='4' align='right'>TPS: $tps$</td> </tr>
		<tr><td colspan='4' align='right'>TVQ: $tvq$</td> </tr>
		<tr><td colspan='4' align='right'>Total: $total$</td> </tr>
		</table>";
		echo"<a href=\"javascript:imprimer('imprimerecherche.php?search=$search')\"> Imprimer </a>";
		
	}
	else
	{
		echo "Aucun resultat!";
	}
}
?>