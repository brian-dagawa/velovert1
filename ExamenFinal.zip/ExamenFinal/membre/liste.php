<?php
//***********  AVANCE ET RECUL **************//
if(isset($_GET["flech"]))
{
	$flech=$_GET["flech"];
	$avancerecul=$_GET["avancerecul"];
	$nbreliste=$_GET["nbreliste"];
	switch($flech)
	{
		case"avant":
			if($avancerecul >=0 and($avancerecul<($nbreliste -3)))
			{
				$avancerecul=$avancerecul+3;
			}
			elseif($avancerecul<($nbreliste -10))
			{
				$avancerecul=$nbreliste;
			}
		break;
		
		case"recul":
			if($avancerecul<=2)
			{
				$avancerecul=0;
			}
			else
			{
				$avancerecul=$avancerecul-3;
			}
		break;
	}
}
else
{
	$avancerecul=0;
}

//***********  AVANCE ET RECUL **************//
include("../connexion.php");
//2) requete de selection des donnees du client
$reqlisteclient=mysqli_query($conn,"select * from velo order by novelo limit $avancerecul,3") or die("Erreur de requete!");

$reqlisteclient2=mysqli_query($conn,"select * from velo order by novelo") or die("Erreur de requete!");
$nbreliste=mysqli_num_rows($reqlisteclient2);

echo "<h3> Liste des velos </h3>";
echo "<table border='1'><th> novelo</th><th>marque </th> <th>prix </th><th>photo </th>";
while($reqresultat=mysqli_fetch_row($reqlisteclient))
{
	$listenovelo=$reqresultat[0];
	$listemarque=$reqresultat[1];
	$listeprix=$reqresultat[2];
	$listephoto=$reqresultat[3];
	
	echo"<tr><td>$listenovelo </td><td>$listemarque </td><td>$listeprix </td>
<td><img src='../photos/$listephoto' style='width:50px;height:50px'></td></tr>";
}
echo "<tr><td colspan='4'><a href='indexmembre.php?lien=liste&avancerecul=$avancerecul&nbreliste=$nbreliste&flech=recul'> <--</a> </td>
<td colspan='5'style='text-align:right;'><a  href='indexmembre.php?lien=liste&avancerecul=$avancerecul&nbreliste=$nbreliste&flech=avant'>  --></a> </td> </tr></table>";
?>