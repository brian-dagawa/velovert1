<?php
	include("../connexion.php");
?>

<?php
	if(isset($_POST["ok"]))
		{
			// 1) recuperation de choix code
			$choixCode=$_POST["choixCode"];
		
			// 2) requete SQL de selection selon code
			$reqCode=mysqli_query($conn,"select * from velo where novelo='$choixCode'");
			
			// 3) affichage des données des membres
		while($reqresultat=mysqli_fetch_row($reqCode))
		{
			$choixCode=$reqresultat[0];
			$choixmarque=$reqresultat[1];
			$choixprix=$reqresultat[2];
		}
		}
		else
			{
		// initialiser les champs
		$choixCode=$choixmarque=$choixprix="";
		
			}
			// 2)Recupération des données transmises par methode="post"
	// si le boutton Valider est cliqué
	if(isset($_POST["valider"]))
		{
			$choixCode=$_POST["choixCode"];
			$valider= $_POST["valider"];
			$marque= $_POST["marque"];
			$prix= $_POST["prix"];
			
			switch($valider)
		{
			case"Update":
				
			$MiseAjour=mysqli_query($conn,"update velo set marque='$marque',prix='$prix'
			where novelo='$choixCode'");
			
			$nbre=mysqli_affected_rows($conn);
	if ($nbre>0)
	{
		echo "UPDATE DONE";
	}
	else
	{
		echo " Echec de mise a jour";
	}  
	break;
	
	case"Delete":
				
			$MiseAjour=mysqli_query($conn,"delete from velo where novelo='$choixCode'");
			
			$nbre=mysqli_affected_rows($conn);
	if ($nbre>0)
	{
		echo "delete ok ";
	}
	else
	{
		echo " Echec de delte";
	}  
	break;
	
	
		}	
		}		
			
			
?>

	<center>
<h3> Modifier  VELO<h3>
 <table>
	<tr>
		<td>
			<form method="post">
				<table border="0">
					<tr>

						<td>
						
							<select name="choixCode" style="width:100%;"> 
								<?php
									// 1) connexion deja faite au tout debut
									// 2) requette SQL de idclient
									$listeCode=mysqli_query($conn,"select novelo from velo");
									while($reqCode=mysqli_fetch_row($listeCode))
									{
										echo "<option value='$reqCode[0]'>$reqCode[0] </option>";
									}
								
								?>
								<option value="novelo"></option>
								
							</select>
							
						</td>  
					
						<td> 
							<input type="submit" name="ok" value="ok">
						</td> 
						
					</tr>
						<tr>
							<td>novelo</td>
						
							<td> <input type="text" name="novelo" value="<?php echo $choixCode; ?>"></td>
						</tr>
						<tr>
							<td> marque </td>
							<td> <input type="text" name="marque" value="<?php echo $choixmarque; ?>"></td>
						</tr>
							
							
							<tr>
								<td> prix</td>
								<td> <input type="text" name="prix" value="<?php echo $choixprix; ?>"></td>
							</tr>
							
							
								<tr><td colspan="2">
										<input type="submit" name="valider" value="Update">
									</td>
								</tr>
								<tr><td colspan="2">
										<input type="submit" name="valider" value="Delete">
									</td>
								</tr>
														 
					</table>
			 </form>
		</td>
		
		<td>
		
		</td>
	</tr>
</table>	
</center>	
