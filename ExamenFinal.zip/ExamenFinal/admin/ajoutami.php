<p>Insription de membre</p>
<form enctype="multipart/form-data"  method="post">
<table>
  <tr><td>nom </td> <td><input type="text" name="nom"></td></tr>
  <tr><td>prenom </td> <td><input type="text" name="prenom"></td></tr>
    <tr><td>telephone </td> <td><input type="text" name="telephone"></td></tr>
  <tr><td>datedenaissance </td> <td><input type="date" name="datedenaissance"></td></tr>
    <tr><td>Photo </td><td><input type="file" name="uploaded_file" ></input></td></tr>
   <tr><td>password </td> <td><input type="password" name="password"></td></tr>
  <tr><td><input type="submit" name="inscrire" value="Inscrire"></input></td></tr>

</table>
</form>

<?php
if(isset($_POST["inscrire"]))
{
  //connexion a la BD
  include("../connexion.php");
 
  $nom=trim($_POST["nom"]);
  $prenom=trim($_POST["prenom"]);
  $telephone=trim($_POST["telephone"]);
  $datedenaissance=trim($_POST["datedenaissance"]);
  $password=trim($_POST["password"]);
   $noami=substr($nom,0,3).substr($prenom,0,1).substr($datedenaissance,0,1);
  if(!empty($_FILES['uploaded_file']))
  {
    $photo=$_FILES['uploaded_file']['name'];
    
    $reqinsert=mysqli_query($conn,"insert into amis 
	values('$noami','$nom','$prenom','$telephone','$datedenaissance','$photo','$password')") 
	or die("Erreur de requete SQL!");
    
	$path = "../photos/";
    $path = $path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) 
    {
        echo "The file ".  basename( $_FILES['uploaded_file']['name']). 
      " has been uploaded";
    } 
    else
    {
        echo "There was an error uploading the file, please try again!";
    }
  }
}
?>