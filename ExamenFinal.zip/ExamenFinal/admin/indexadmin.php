
<style>
	li{
		display:inline;
		margin-right:100px;
	}
	
</style>
<center>
		
		<!-- menu -->
		<div style="height:5%;width:85%;background-color:white;">
			<ol>
				<li><a href="indexadmin.php?lien=ajout">ADD VELO </a> </li>
				<li><a href="indexadmin.php?lien=ajoutami">ADD AMIS  </a> </li>
				<li><a href="indexadmin.php?lien=miseajour">UPDATE VELO </a> </li>
				<li><a href="indexadmin.php?lien=suppression">UPDATE AMIS</a> </li>
				<li><a href="indexadmin.php?lien=recherche">RECHERCHE </a> </li>
				
			</ol>
		</div>

		<!-- details -->
		<?php
		 //Recuperation de la valeur du lien(lien can be given any name)
		 if(isset($_GET["lien"]))
		 {
			 $lien =$_GET["lien"];
			//selon le lien clique, inclure le contenu de la case
			switch($lien)
			{
		
				case"ajout":
					include("ajout.php");
				break;
				
				case"ajoutami":
					include("ajoutami.php");
				break;
				case"miseajour":
					include("miseajour.php");
				break;
				case"suppression":
					include("suppression.php");
				break;
				case"recherche":
					include("recherche.php");
				break;
				case"deconnexion":
					include("deconnexion.php");
				break;
			}
		 }
		?>
		
</center>