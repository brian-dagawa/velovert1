<script>
	window.print();
</script>

<?php

$search=$_GET["search"];
echo "<h3> Resultat de la recherche pour $search</h3>";
//2)connexion a la BD
include("../connexion.php");
//3) Requete de selection de livre
$affichelivre=mysqli_query($conn,"select * from velo 
where novelo='$search' or marque='$search'");

//3) Affichage des livres
echo"<table><tr><th>novelo </th> <th>marque </th>
<th>Prix </th><th> Photo</th></tr>";
while($resultatlivre=mysqli_fetch_row($affichelivre))
{
	$novelo=$resultatlivre[0];
	$marque=$resultatlivre[1];
	$prix=$resultatlivre[2];
	$photo=$resultatlivre[3];
	//Calcul du sous-total
	$stotal +=$prix;
	echo"<tr><td>$novelo </td> <td> $marque</td>
	<td> $prix$</td>
	<td><img src='photos/$photo' style='height:150px;width:150px;'> 
	</td></tr>";
}
//Calcul des taxes et du total
$tps=$stotal*0.05;
$tvq=$stotal*0.975;
$total=$stotal+$tps+$tvq;
echo"<tr><td colspan='4' align='right'>Sous-Total: $stotal$</td> </tr>
<tr><td colspan='4' align='right'>TPS: $tps$</td> </tr>
<tr><td colspan='4' align='right'>TVQ: $tvq$</td> </tr>
<tr><td colspan='4' align='right'>Total: $total$</td> </tr>
</table>";
	
		
	
?>