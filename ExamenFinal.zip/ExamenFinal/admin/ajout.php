
	<h3>ISNCRIPTION DE NOUVEAU VELO!</h3>
 <center> <form enctype="multipart/form-data" method="post">
   <table>
      <tr><td>novelo </td> <td><input type="text" name="novelo"></td></tr>
	  <tr><td>marque </td> <td><input type="text" name="marque"></td></tr>
      <tr><td>prix </td> <td><input type="text" name="prix"></td></tr>
      <tr><td>Photo </td><td><input type="file" name="uploaded_file"></input></td></tr>
      <tr><td><input type="submit" name="inscrire" value="AJOUTER"></input></td></tr>
    
    </table>
  </form></center>

<?php
if(isset($_POST["inscrire"]))
{
  //connexion a la BD
  include("../connexion.php");
 $novelo=trim($_POST["novelo"]);
 $marque=trim($_POST["marque"]);
 $prix=trim($_POST["prix"]);
 
  if(!empty($_FILES['uploaded_file']))
  {
    $photo=$_FILES['uploaded_file']['name'];
	
    $reqinsert=mysqli_query($conn,"insert into velo values('$novelo','$marque','$prix','$photo')") 
	or die("Erreur de requete SQL!");
    $path = "../photos/";
    $path = $path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) 
    {
        echo "The file ".  basename( $_FILES['uploaded_file']['name']). 
      " has been uploaded";
    } 
    else
    {
        echo "There was an error uploading the file, please try again!";
    }
  }
}
?>


